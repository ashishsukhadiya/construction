# animated-galleries
## Animated galleries created with jQuery and SCSS

Here is the link to the project: https://tizianavinciguerra.github.io/animated-galleries/
